// server.js

const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// MySQL database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Akshay@1008',
    database: 'Library'
});

db.connect((err) => {
    if (err) {
        console.error('❌ Database connection failed:', err.message);
    } else {
        console.log('✅ Database Connected');
    }
});

// Root endpoint
app.get('/', (req, res) => {
    res.send('📚 Library API is running');
});

// Get all books
app.get('/books', (req, res) => {
    db.query('SELECT * FROM Books', (err, results) => {
        if (err) {
            console.error('❌ Error fetching books:', err.message);
            res.status(500).json({ error: 'Failed to fetch books' });
        } else {
            res.json(results);
        }
    });
});

// Add a new book
app.post('/create', (req, res) => {
    const { Name, Price } = req.body;
    db.query('INSERT INTO Books (Name, Price) VALUES (?, ?)', [Name, Price], (err, result) => {
        if (err) {
            console.error('❌ Error inserting book:', err.message);
            res.status(500).json({ error: 'Failed to add book' });
        } else {
            res.json({ bookId: result.insertId });
        }
    });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log('Server is running at http://localhost:${PORT}');
});
