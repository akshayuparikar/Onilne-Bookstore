import React, { useEffect, useState } from "react";
import axios from "axios";
import './App.css';

function Books() {
  const [books, setBooks] = useState([]);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');

  const handleAdd = () => {
    axios.post("http://localhost:3000/create", { Name: name, Price: price })
      .then((response) => {
        console.log("✅ Data added:", response.data);
        alert("Book added successfully!");
        setName('');
        setPrice('');
        fetchBooks(); // Refresh list
      })
  };

  const fetchBooks = () => {
    axios.get("http://localhost:3000/books")
      setBooks(response.data)
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  return (
    <div className="header">
      <h2>📚 Book List</h2>
      <div className="input">
        Add Book Name:
        <input
          type="text"
          placeholder="Book name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <br />
        Add Book Price:
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
      </div>

      <div className="Submit">
        <button onClick={handleAdd}>Add Record</button>
        <button onClick={() => { setName(''); setPrice(''); }}>Reset</button>
      </div>
      <br />

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Name</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {books.map((b, i) => (
            <tr key={i}>
              <td>{b.Name}</td>
              <td>{b.Price}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Books;
